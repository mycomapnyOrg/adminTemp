<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>412 Precondition Failed</title>
</head><body>
<h1>Precondition Failed</h1>
<p>The precondition on the request for the URL /westilo-admin/full-width-fluid-layout/php/captcha/captcha-image.php evaluated to false.</p>
</body></html>
